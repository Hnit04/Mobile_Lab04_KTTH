import { StyleSheet, FlatList,TouchableOpacity, Text, View } from 'react-native';

import React,{ useState } from "react"


export default function App() {
  const [cart, setCart]= useState([]);
  const products=[
     {id:"1", name:"Sản phẩm A", price:10000},
      {id:"2", name:"Sản phẩm B", price:20000},
       {id:"3", name:"Sản phẩm C", price:30000},
   ];
   const totalPrice= cart.reduce((sum,item)=> sum+ item.price,0)
   const addToCart=(item)=>{
     setCart([...cart, item]);
     alert(`Đã thêm ${item.name} va giỏ hàng`);
   }
   const renderItem=({item})=>{
     return(
       <View style={{padding:15, margin:10, backgroundColor:"blue"}}>
      <Text style={{fontSize:16, fontWeight:"bold"}}>{item.name}</Text>
      <Text>{item.price} đ</Text>
      <TouchableOpacity style={{marginTop: 5, backgroundColor:"green", padding:10, alignItems:"center"}} onPress={()=>addToCart(item)}>
        <Text> Thêm vào giỏ hàng</Text>
      </TouchableOpacity>
     </View>
     );
     
   }
  return (
   <View style={{flex: 1, padding:10, justifyContent:"center", alignItems:"center"}}>
    <Text>Danh sach</Text>
    <FlatList data={products} renderItem={renderItem} keyExtractor={(item)=>item.id}
    />
    <View style={{padding:15, backgroundColor:"orabge",alignItems:"center"}}>
      <Text> 
        Giỏ hàng có {cart.length} sản phẩm
      </Text>
      <Text> 
        Tổng tiền giỏ hàng: {totalPrice}
      </Text>
    </View>
   </View>
  );
}


